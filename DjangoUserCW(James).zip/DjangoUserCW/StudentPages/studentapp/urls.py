from . import views
from django.urls import path, include
# Contributed: James Tyrwhitt, Amina Imran
urlpatterns = [
    path('', views.homePage),               # home page directory
    path('home/', views.homePage),
    path('accounts/', include('django.contrib.auth.urls')),

    path('userLogin', views.userLogin),                 # user choice for sign in or sign up
    path('userSignupPage', views.userSignupPage),       # user sign up page
    path('userLoginPage', views.userLoginPage, name='login'),         # user login page
    path('adminLogin', views.adminLogin),               # admin login page

    path('userHomePage', views.userHomePage, name='homePage'),                       # user home page
    path('account/', views.accountPage),                            # user account information page
    path('account/update/', views.updateAccountPage),               # user account update page
    path('account/update/confirmed/', views.updateAccountPage),     
    path('equipment/', views.equipmentsPage),                       # user equipment page
    path('reservation/', views.reservationsPage),                   # user reservation page
    path('reservation/bookequipment/', views.bookEquipmentPage),
    path('notification/', views.notificationsPage),

    path('adminHome', views.adminHome),
    path('UserManagement', views.userManagement),
    path('EquipmentManagement', views.equipmentManagement),
    path('ReportGenerator', views.reportGenerator),

    # path('CreateUserAccount.html', views.register),
]
