from django.shortcuts import redirect, render
from django.http import HttpResponse
from .forms import UserRegisterForm
from .models import *
from django.db.models import Q
from django.contrib.auth import authenticate,login

# Create your views here.
# Contributed: James Tyrwhitt, Amina Imran
def homePage(request):                                              # home page directory
    return render(request, 'studentapp/loginDirector.html')


def userLogin(request):                                             # user choice page for login or sign up  
    return render(request, 'studentapp/userLoginOrSignup.html')     

def userSignupPage(request):                                        # user signup page
    return render(request, 'studentapp/USER SIGNUP PAGE.html')

def userLoginPage(request):                                         # user login page
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, customerUsername=username, customerPassword=password)
        if user is not None:
            login(request, user)
            return views.userHomePage
        else:
            error = "Invalid username or password. Please try again."
            return render(request, 'studentapp/userloginPage.html')
    else:
        return render(request, 'studentapp/userloginPage.html')

def adminLogin(request):                                            # admin login page
    return render(request, 'studentapp/Admin login.html')


def userHomePage(request):                                          # user home page
    return render(request, 'studentapp/home.html')


def accountPage(request):                                           # user account page
    return render(request, 'studentapp/AccountSection/account.html')

def updateAccountPage(request):                                     # user update account page 
    return render(request, 'studentapp/AccountSection/update.html')

def updateConfirmPage(request):                                     # user account page update confirmation 
    return render(request, 'studentapp/AccountSection/confirmed.html')

def equipmentsPage(request):                                        # user equipment page
    if request.method == 'POST':
        search = request.POST.get('search')
        lookup = (Q(equipmentName__icontains=search) | Q(equipmentType__icontains=search) | Q(quantity__icontains=search) | Q(status__icontains=search) | Q(location__icontains=search))
        searchResult = Equipment.objects.filter(lookup)
        return render(request, 'studentapp/equipment.html', {'equipment' : searchResult})
    else:
        equipment = Equipment.objects.all()
        return render(request, 'studentapp/equipment.html', {'equipment' : equipment})


def reservationsPage(request):                                      # user reservation page
    return render(request, 'studentapp/ReservationsSection/reservation.html')

def bookEquipmentPage(request):                                     # user booking equipment page
    return render(request, 'studentapp/ReservationsSection/bookequipment.html')

def notificationsPage(request):                                     # user notification page
    return render(request, 'studentapp/notification.html')


def adminHome(request):                                             # admin home page
    return render(request, 'studentapp/homeAdmin.html')

def userManagement(request):                                        # admin user managment page
    return render(request, 'studentapp/UserManagement.html')

def equipmentManagement(request):                                   # admin equipment page
    equipment = Equipment.objects.all()
    return render(request, 'studentapp/EquipmentManagement.html', {'equipment' : equipment})

def reportGenerator(request):                                       # admin report generator page
    return render(request, 'studentapp/ReportGenerator.html')
