#Royal Rai
#Amina Imran
from . import views
from django.urls import path, include

urlpatterns = [
    path('', views.dashboard_director, name='dashboard-director'),  # Set as the homepage
    path('user-login/', views.user_login, name='user-login'),
    path('First-page/', views.First_page, name='First-page'),
    path('admin-login/', views.admin_login, name='admin-login'),
    path('user-Signup/', views.user_Signup, name='user-Signup'),
    path('home/', views.homePage),
    path('account/', views.accountPage),
    path('account/update/', views.updateAccountPage),
    path('account/update/confirmed/', views.updateAccountPage),
    path('equipment/', views.equipmentsPage),
    path('reservation/', views.reservationsPage),
    path('reservation/bookequipment/', views.bookEquipmentPage),
    path('notification/', views.notificationsPage),
    path('CreateUserAccount.html', views.register),
    path('generate-pdf-report/', views.generate_pdf_report, name='generate_pdf_report'),
    path('booking-confirmed/', views.bookingconfirmed, name='booking-confirmed'),
]
