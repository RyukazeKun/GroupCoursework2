# Royal Rai
# Amina Imran
# Antonio Aciobanitei
# James Tyrwhitt
from django.shortcuts import redirect, render
from django.http import HttpResponse
from reportlab.pdfgen import canvas
from .forms import UserRegisterForm
from .models import Equipment
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib.auth.hashers import make_password

# Made by antonio
def dashboard_director(request):
    # first page of the html file
    return render(request, 'Dashboard Director.html')


def First_page(request):
    # signup or login page render
    return render(request, 'User login or signup director.html')


def admin_login(request):
    # when request is sent
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        # if user is admin
        if user is not None and user.is_admin:
            login(request, user)
            return redirect('admin_dashboard')
            # if user is not admin
        else:
            messages.error(request, 'Invalid username or password')
    return render(request, 'Admin login page.html')


def user_login(request):
    # when request is sent
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        # authentication
        user = authenticate(request, username=username, password=password)
        # if credentials are correct
        if user is not None:
            login(request, user)
            return render(request, 'studentapp/home.html')
        else:
            # if credentials are wrong
            messages.error(request, 'Invalid username or password')
    return render(request, 'User login page.html')


def user_Signup(request):
    # when request is sent
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        name = request.POST.get('name')
        password = request.POST.get('password')
        role = request.POST.get('role')

        # validation
        if not (username and email and name and password):
            messages.error(request, "Please fill in all required fields.")
            return redirect('user-Signup')
        # if it already exists
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return redirect('user-Signup')

        # Create user
        user = User.objects.create(
            username=username,
            email=email,
            first_name=name,
            password=make_password(password)  # hash the password
        )
        user.save()
        # succful account creation
        messages.success(request, "Account successfully created!")
        return render(request, 'studentapp/home.html')

        # starts page
    return render(request, 'User signup page.html')

# Create your views here.

def homePage(request):
    return render(request, 'studentapp/home.html')

def accountPage(request):
    return render(request, 'studentapp/AccountSection/account.html')

def updateAccountPage(request):
    return render(request, 'studentapp/AccountSection/update.html')

def updateConfirmPage(request):
    return render(request, 'studentapp/AccountSection/confirmed.html')

def equipmentsPage(request):
    return render(request, 'studentapp/equipment.html')

def bookingconfirmed(request):
    return render(request, 'studentapp/ReservationsSection/bookingconfirmed.html')
def reservationsPage(request):
    return render(request, 'studentapp/ReservationsSection/reservation.html')

def bookEquipmentPage(request):
    return render(request, 'studentapp/ReservationsSection/bookequipment.html')

def notificationsPage(request):
    return render(request, 'studentapp/notification.html')

def register(request):              # function for create user account page
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()

            return redirect('userLogin.html')
    else:
        form = UserRegisterForm()
    return render(request, 'CreateUserAccount.html', {'form': form})



def reservation_history(request):
    search_query = request.GET.get('search', '')
    equipments = Equipment.objects.filter(name__icontains=search_query)

    if 'generate_pdf' in request.GET:
        return generate_pdf_report(equipments)

    return render(request, 'reservation_history.html', {'equipments': equipments})



def generate_pdf_report(request,):
    equipments = Equipment.objects.all()
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="equipments_report.pdf"'
    p = canvas.Canvas(response)
    p.setFont("Helvetica-Bold", 16)
    p.drawString(100, 800, "Equipment Report")
    p.setFont("Helvetica", 12)
    y = 780
    p.drawString(30, y, "ID")
    p.drawString(80, y, "Name")
    p.drawString(220, y, "Type")
    p.drawString(360, y, "Quantity")
    p.drawString(460, y, "Status")
    for equipment in equipments:
        y -= 20
        if y < 100:
            p.showPage()
            y = 780
        p.drawString(30, y, str(equipment.equipmentID))
        p.drawString(80, y, equipment.equipmentName)
        p.drawString(220, y, equipment.equipmentType)
        p.drawString(360, y, str(equipment.quantity))
        p.drawString(460, y, equipment.status)
    p.showPage()
    p.save()
    return response
